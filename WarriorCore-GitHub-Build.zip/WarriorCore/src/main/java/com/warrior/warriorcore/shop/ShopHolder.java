package com.warrior.warriorcore.shop;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/** Marks an inventory as a shop GUI. category == null means the main menu. */
public class ShopHolder implements InventoryHolder {

    private final String category;
    private Inventory inventory;

    public ShopHolder(String category) {
        this.category = category;
    }

    public String category() {
        return category;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
