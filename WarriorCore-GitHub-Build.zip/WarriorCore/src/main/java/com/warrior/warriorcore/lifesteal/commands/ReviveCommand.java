package com.warrior.warriorcore.lifesteal.commands;

import com.warrior.warriorcore.Util;
import com.warrior.warriorcore.lifesteal.ItemManager;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.UUID;

public class ReviveCommand implements TabExecutor {

    private final LifestealModule plugin;

    public ReviveCommand(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }
        if (args.length < 1) {
            p.sendMessage(plugin.msg("revive-usage"));
            return true;
        }

        UUID target = plugin.findPlayer(args[0]);
        if (target == null) {
            p.sendMessage(plugin.msg("player-not-found"));
            return true;
        }
        String targetName = plugin.hearts().nameOf(target);
        if (!plugin.hearts().isEliminated(target)) {
            p.sendMessage(plugin.msg("revive-not-eliminated", "player", targetName));
            return true;
        }

        if (plugin.getConfig().getBoolean("revive.require-item", true)) {
            int slot = -1;
            ItemStack[] contents = p.getInventory().getStorageContents();
            for (int i = 0; i < contents.length; i++) {
                if (ItemManager.REVIVE.equals(plugin.items().typeOf(contents[i]))) {
                    slot = i;
                    break;
                }
            }
            if (slot < 0) {
                p.sendMessage(plugin.msg("revive-no-item"));
                return true;
            }
            ItemStack item = p.getInventory().getItem(slot);
            if (item != null) {
                if (item.getAmount() <= 1) {
                    p.getInventory().setItem(slot, null);
                } else {
                    item.setAmount(item.getAmount() - 1);
                    p.getInventory().setItem(slot, item);
                }
            }
        }

        plugin.hearts().revive(target, plugin.getConfig().getInt("elimination.revive-hearts", 3));
        p.sendMessage(plugin.msg("revived-sender", "player", targetName));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Util.match(plugin.hearts().eliminatedNames(), args[0]);
        }
        return List.of();
    }
}
