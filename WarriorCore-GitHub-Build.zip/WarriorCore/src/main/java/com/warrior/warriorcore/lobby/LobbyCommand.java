package com.warrior.warriorcore.lobby;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

/** /lobby (alias /hub) and /setlobby. */
public class LobbyCommand implements TabExecutor {

    private final LobbyModule lobby;

    public LobbyCommand(LobbyModule lobby) {
        this.lobby = lobby;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(lobby.msg("players-only"));
            return true;
        }
        if (command.getName().equalsIgnoreCase("setlobby")) {
            if (!p.hasPermission("warriorcore.lobby.admin")) {
                p.sendMessage(lobby.msg("no-permission"));
                return true;
            }
            lobby.setLobby(p.getLocation());
            p.sendMessage(lobby.msg("lobby-set"));
            return true;
        }
        if (lobby.teleportToLobby(p)) {
            p.sendMessage(lobby.msg("teleported"));
        } else {
            p.sendMessage(lobby.msg("no-lobby"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
