package com.warrior.warriorcore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;

public class ModuleManager {

    private final WarriorCore core;
    private final List<CoreModule> all = new ArrayList<>();
    private final List<CoreModule> enabled = new ArrayList<>();

    public ModuleManager(WarriorCore core) {
        this.core = core;
    }

    public void add(CoreModule module) {
        all.add(module);
    }

    public void enableAll() {
        for (CoreModule m : all) {
            boolean on = core.getConfig().getBoolean("modules." + m.id(), true);
            if (!on) {
                core.getLogger().info("Module '" + m.id() + "' is turned off in config.yml");
                continue;
            }
            try {
                m.loadConfig();
                m.enable();
                enabled.add(m);
                core.getLogger().info("Module '" + m.id() + "' enabled.");
            } catch (Exception | LinkageError ex) {
                core.getLogger().log(Level.SEVERE, "Module '" + m.id() + "' failed to start and was skipped", ex);
                m.unregisterListeners();
            }
        }
    }

    public void disableAll() {
        List<CoreModule> reversed = new ArrayList<>(enabled);
        Collections.reverse(reversed);
        for (CoreModule m : reversed) {
            try {
                m.disable();
            } catch (Exception | LinkageError ex) {
                core.getLogger().log(Level.WARNING, "Module '" + m.id() + "' errored while disabling", ex);
            }
            m.unregisterListeners();
        }
        enabled.clear();
    }

    public void reloadAll() {
        for (CoreModule m : enabled) {
            try {
                m.reload();
            } catch (Exception | LinkageError ex) {
                core.getLogger().log(Level.WARNING, "Module '" + m.id() + "' failed to reload", ex);
            }
        }
    }

    /** The running module of this type, or null if it is off. */
    public <T extends CoreModule> T get(Class<T> type) {
        for (CoreModule m : enabled) {
            if (type.isInstance(m)) return type.cast(m);
        }
        return null;
    }

    public List<CoreModule> all() { return all; }

    public boolean isEnabled(CoreModule m) { return enabled.contains(m); }
}
