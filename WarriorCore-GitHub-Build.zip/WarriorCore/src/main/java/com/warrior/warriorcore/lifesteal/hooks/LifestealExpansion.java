package com.warrior.warriorcore.lifesteal.hooks;

import com.warrior.warriorcore.lifesteal.HeartManager;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

/** PlaceholderAPI expansion: %warriorlifesteal_<placeholder>% */
public class LifestealExpansion extends PlaceholderExpansion {

    private final LifestealModule plugin;

    public LifestealExpansion(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getIdentifier() {
        return "warriorlifesteal";
    }

    @Override
    public String getAuthor() {
        return "Warrior";
    }

    @Override
    public String getVersion() {
        return plugin.core().getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        HeartManager hm = plugin.hearts();
        String p = params.toLowerCase();

        // Leaderboard: top_<n>_name / top_<n>_hearts
        if (p.startsWith("top_")) {
            String[] parts = p.split("_");
            if (parts.length != 3) return null;
            int n;
            try {
                n = Integer.parseInt(parts[1]);
            } catch (NumberFormatException ex) {
                return null;
            }
            List<UUID> top = hm.top();
            boolean wantName = parts[2].equals("name");
            if (!wantName && !parts[2].equals("hearts")) return null;
            if (n < 1 || n > top.size()) {
                return plugin.color(plugin.getConfig().getString(
                        wantName ? "placeholders.empty-name" : "placeholders.empty-value", wantName ? "-" : "0"));
            }
            UUID id = top.get(n - 1);
            return wantName ? hm.nameOf(id) : String.valueOf(hm.getHearts(id));
        }

        if (player == null) return "";
        UUID id = player.getUniqueId();
        String yes = plugin.color(plugin.getConfig().getString("placeholders.yes", "yes"));
        String no = plugin.color(plugin.getConfig().getString("placeholders.no", "no"));

        switch (p) {
            case "hearts":
                return String.valueOf(hm.getHearts(id));
            case "hearts_max":
                return String.valueOf(hm.maxHearts());
            case "health":
                return String.valueOf(hm.getHearts(id) * 2);
            case "hearts_bar": {
                int full = Math.min(hm.getHearts(id), hm.maxHearts());
                int empty = Math.max(0, hm.maxHearts() - full);
                String f = plugin.getConfig().getString("placeholders.heart-full", "&c#");
                String e = plugin.getConfig().getString("placeholders.heart-empty", "&7#");
                return plugin.color(f.repeat(full) + e.repeat(empty));
            }
            case "eliminated":
                return hm.isEliminated(id) ? yes : no;
            case "enabled": {
                Player online = player.getPlayer();
                return online != null && plugin.isActiveIn(online.getWorld()) ? yes : no;
            }
            default:
                return null;
        }
    }
}
