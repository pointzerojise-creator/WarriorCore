package com.warrior.warriorcore.lifesteal.listeners;

import com.warrior.warriorcore.lifesteal.HeartManager;
import com.warrior.warriorcore.lifesteal.ItemManager;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;

public class MainListener implements Listener {

    private final LifestealModule plugin;

    public MainListener(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.hearts().rememberPlayer(p.getUniqueId(), p.getName());
        if (plugin.getConfig().getBoolean("recipes.discover-on-join", true)) {
            p.discoverRecipes(plugin.items().getRecipeKeys());
        }
        Bukkit.getScheduler().runTaskLater(plugin.core(), () -> plugin.applyState(p), 3L);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin.core(), () -> plugin.applyState(p), 3L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin.core(), () -> plugin.applyState(p), 3L);
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        if (!plugin.isActiveIn(victim.getWorld())) return;

        FileConfiguration cfg = plugin.getConfig();
        HeartManager hm = plugin.hearts();

        Player killer = victim.getKiller();
        if (killer != null && killer.getUniqueId().equals(victim.getUniqueId())) killer = null;
        boolean pvp = killer != null;

        int per = Math.max(1, cfg.getInt("hearts.per-kill", 1));
        boolean victimLoses = pvp
                ? cfg.getBoolean("hearts.lose-on-pvp-death", true)
                : cfg.getBoolean("hearts.lose-on-natural-death", false);

        int lost = 0;
        UUID victimId = victim.getUniqueId();
        if (victimLoses) {
            int before = hm.getHearts(victimId);
            int after = Math.max(0, before - per);
            lost = before - after;
            hm.setHearts(victimId, after);
            victim.sendMessage(plugin.msg("death-lose",
                    "amount", String.valueOf(lost), "hearts", String.valueOf(after)));
            if (after <= 0) {
                hm.eliminate(victimId);
            }
        }

        if (pvp && cfg.getBoolean("hearts.gain-on-kill", true)) {
            int gain = victimLoses ? lost : per;
            if (gain > 0) {
                giveKillerHearts(killer, victim, gain);
            }
        }
    }

    private void giveKillerHearts(Player killer, Player victim, int gain) {
        HeartManager hm = plugin.hearts();
        UUID kid = killer.getUniqueId();
        int current = hm.getHearts(kid);
        int max = hm.maxHearts();

        int canTake = Math.max(0, max - current);
        int taken = Math.min(gain, canTake);
        int remainder = gain - taken;

        if (taken > 0) {
            hm.setHearts(kid, current + taken);
            plugin.applyState(killer);
            killer.sendMessage(plugin.msg("kill-gain",
                    "amount", String.valueOf(taken),
                    "victim", victim.getName(),
                    "hearts", String.valueOf(current + taken)));
        }

        if (remainder > 0) {
            if (plugin.getConfig().getBoolean("hearts.drop-heart-item-at-max", true)) {
                ItemStack heartItem = plugin.items().build(ItemManager.HEART, remainder);
                if (heartItem != null) {
                    Map<Integer, ItemStack> left = killer.getInventory().addItem(heartItem);
                    for (ItemStack extra : left.values()) {
                        killer.getWorld().dropItemNaturally(killer.getLocation(), extra);
                    }
                }
            } else if (taken == 0) {
                killer.sendMessage(plugin.msg("max-reached"));
            }
        }
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action action = e.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        String type = plugin.items().typeOf(e.getItem());
        if (type == null) return;

        e.setCancelled(true);
        Player p = e.getPlayer();

        if (type.equals(ItemManager.REVIVE)) {
            p.sendMessage(plugin.msg("revive-use-command"));
            return;
        }
        if (!type.equals(ItemManager.HEART)) return;

        if (!plugin.isActiveIn(p.getWorld())) {
            p.sendMessage(plugin.msg("not-in-world"));
            return;
        }

        HeartManager hm = plugin.hearts();
        UUID id = p.getUniqueId();
        int give = Math.max(1, plugin.getConfig().getInt("items.heart.hearts-given", 1));
        int current = hm.getHearts(id);
        int max = hm.maxHearts();
        if (current >= max) {
            p.sendMessage(plugin.msg("max-reached"));
            return;
        }

        int gained = Math.min(give, max - current);
        hm.setHearts(id, current + gained);

        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getAmount() <= 1) {
            p.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
            p.getInventory().setItemInMainHand(hand);
        }

        plugin.applyState(p);
        p.sendMessage(plugin.msg("heart-used",
                "amount", String.valueOf(gained), "hearts", String.valueOf(current + gained)));
    }
}
