package com.warrior.warriorcore.shop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public class ShopListener implements Listener {

    private final ShopModule shop;

    public ShopListener(ShopModule shop) {
        this.shop = shop;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof ShopHolder holder)) return;
        e.setCancelled(true);

        if (e.getClickedInventory() == null || e.getClickedInventory() != top) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        int slot = e.getSlot();

        if (holder.category() == null) {
            ShopModule.Category c = shop.categoryAtSlot(slot);
            if (c != null) shop.openCategory(p, c);
            return;
        }

        if (slot == 49) {
            shop.openMain(p);
            return;
        }
        ShopModule.Category cat = shop.category(holder.category());
        if (cat == null || slot < 0 || slot >= cat.items.size()) return;
        ShopModule.ShopItem item = cat.items.get(slot);

        ClickType click = e.getClick();
        switch (click) {
            case LEFT: shop.buy(p, item, 1); break;
            case SHIFT_LEFT: shop.buy(p, item, 64); break;
            case RIGHT: shop.sell(p, item, 1); break;
            case SHIFT_RIGHT: shop.sell(p, item, 64); break;
            default: break;
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof ShopHolder) {
            e.setCancelled(true);
        }
    }
}
