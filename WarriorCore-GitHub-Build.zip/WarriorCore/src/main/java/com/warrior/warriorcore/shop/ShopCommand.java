package com.warrior.warriorcore.shop;

import com.warrior.warriorcore.Util;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

/** /shop opens the GUI, /sell hand sells what you hold. */
public class ShopCommand implements TabExecutor {

    private final ShopModule shop;

    public ShopCommand(ShopModule shop) {
        this.shop = shop;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(shop.msg("players-only"));
            return true;
        }
        if (command.getName().equalsIgnoreCase("sell")) {
            if (args.length >= 1 && args[0].equalsIgnoreCase("hand")) {
                shop.sellHand(p);
            } else {
                p.sendMessage(shop.msg("sell-usage"));
            }
            return true;
        }
        shop.openMain(p);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("sell") && args.length == 1) {
            return Util.match(List.of("hand"), args[0]);
        }
        return List.of();
    }
}
