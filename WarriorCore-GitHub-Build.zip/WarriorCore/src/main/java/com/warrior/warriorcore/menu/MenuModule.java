package com.warrior.warriorcore.menu;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import com.warrior.warriorcore.lobby.LobbyModule;
import com.warrior.warriorcore.worlds.WorldsModule;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Config-driven GUI menus with click actions. */
public class MenuModule extends CoreModule {

    private static final Pattern ACTION = Pattern.compile("^\\[(\\w+)\\]\\s*(.*)$");

    public static class MenuItem {
        public final ItemStack stack;
        public final List<String> actions;

        public MenuItem(ItemStack stack, List<String> actions) {
            this.stack = stack;
            this.actions = actions;
        }
    }

    public static class Menu {
        public final String id;
        public String title = "Menu";
        public int rows = 3;
        public Material fill = null;
        public final Map<Integer, MenuItem> items = new HashMap<>();

        public Menu(String id) {
            this.id = id;
        }
    }

    private final Map<String, Menu> menus = new LinkedHashMap<>();
    private final Map<String, String> byCommand = new HashMap<>();

    public MenuModule(WarriorCore core) {
        super(core, "menu");
    }

    @Override
    public void enable() {
        load();
        command("menu", new MenuCommand(this));
        listen(new MenuListener(this));
    }

    @Override
    public void reload() {
        loadConfig();
        load();
    }

    // ------------------------------------------------------------------ config

    private void load() {
        menus.clear();
        byCommand.clear();
        ConfigurationSection root = cfg().getConfigurationSection("menus");
        if (root == null) return;

        for (String id : root.getKeys(false)) {
            ConfigurationSection ms = root.getConfigurationSection(id);
            if (ms == null) continue;

            Menu menu = new Menu(id);
            menu.title = ms.getString("title", id);
            menu.rows = Math.max(1, Math.min(6, ms.getInt("rows", 3)));
            String fill = ms.getString("fill");
            if (fill != null) {
                Material m = Material.matchMaterial(fill);
                if (m != null && m.isItem()) menu.fill = m;
            }

            ConfigurationSection items = ms.getConfigurationSection("items");
            if (items != null) {
                for (String key : items.getKeys(false)) {
                    ConfigurationSection is = items.getConfigurationSection(key);
                    if (is == null) continue;
                    int slot = is.getInt("slot", 0);
                    if (slot < 0 || slot >= menu.rows * 9) {
                        getLogger().warning("[menu] " + id + "." + key + ": slot " + slot + " is outside the menu");
                        continue;
                    }
                    Material mat = Material.matchMaterial(is.getString("material", "STONE"));
                    if (mat == null || !mat.isItem() || mat.isAir()) {
                        getLogger().warning("[menu] " + id + "." + key + ": unknown material, using STONE");
                        mat = Material.STONE;
                    }
                    ItemStack stack = new ItemStack(mat, Math.max(1, Math.min(64, is.getInt("amount", 1))));
                    ItemMeta meta = stack.getItemMeta();
                    if (meta != null) {
                        meta.setDisplayName(color(is.getString("name", key)));
                        List<String> lore = new ArrayList<>();
                        for (String line : is.getStringList("lore")) lore.add(color(line));
                        if (!lore.isEmpty()) meta.setLore(lore);
                        stack.setItemMeta(meta);
                    }
                    menu.items.put(slot, new MenuItem(stack, is.getStringList("actions")));
                }
            }
            menus.put(id.toLowerCase(), menu);

            String open = ms.getString("open-command");
            if (open != null && !open.trim().isEmpty()) {
                byCommand.put(open.trim().toLowerCase().replace("/", ""), id.toLowerCase());
            }
        }
    }

    public Menu menu(String id) {
        return id == null ? null : menus.get(id.toLowerCase());
    }

    public List<String> menuIds() {
        return new ArrayList<>(menus.keySet());
    }

    /** Menu id for a typed command like "gamemodes", or null. */
    public String menuForCommand(String command) {
        return byCommand.get(command.toLowerCase());
    }

    // -------------------------------------------------------------------- open

    public boolean open(Player p, String id) {
        Menu menu = menu(id);
        if (menu == null) return false;

        MenuHolder holder = new MenuHolder(menu.id);
        Inventory inv = Bukkit.createInventory(holder, menu.rows * 9, color(menu.title));
        holder.setInventory(inv);

        if (menu.fill != null) {
            ItemStack filler = new ItemStack(menu.fill);
            ItemMeta fm = filler.getItemMeta();
            if (fm != null) {
                fm.setDisplayName(" ");
                filler.setItemMeta(fm);
            }
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        }

        for (Map.Entry<Integer, MenuItem> entry : menu.items.entrySet()) {
            ItemStack shown = entry.getValue().stack.clone();
            ItemMeta meta = shown.getItemMeta();
            if (meta != null) {
                if (meta.hasDisplayName()) meta.setDisplayName(meta.getDisplayName().replace("%player%", p.getName()));
                if (meta.hasLore() && meta.getLore() != null) {
                    List<String> lore = new ArrayList<>();
                    for (String line : meta.getLore()) lore.add(line.replace("%player%", p.getName()));
                    meta.setLore(lore);
                }
                shown.setItemMeta(meta);
            }
            inv.setItem(entry.getKey(), shown);
        }
        p.openInventory(inv);
        return true;
    }

    // ----------------------------------------------------------------- actions

    /** Runs the actions on the next tick (safe to do from inside a click event). */
    public void runActions(Player p, List<String> actions) {
        final List<String> copy = new ArrayList<>(actions);
        Bukkit.getScheduler().runTask(core, () -> {
            for (String raw : copy) {
                Matcher m = ACTION.matcher(raw.trim());
                if (!m.matches()) {
                    getLogger().warning("[menu] bad action (use [type] value): " + raw);
                    continue;
                }
                String type = m.group(1).toLowerCase();
                String arg = m.group(2).replace("%player%", p.getName()).trim();
                if (arg.startsWith("/")) arg = arg.substring(1);

                switch (type) {
                    case "player":
                        p.performCommand(arg);
                        break;
                    case "console":
                        Bukkit.dispatchCommand(Bukkit.getConsoleSender(), arg);
                        break;
                    case "message":
                        p.sendMessage(color(m.group(2).replace("%player%", p.getName())));
                        break;
                    case "close":
                        p.closeInventory();
                        break;
                    case "sound":
                        p.playSound(p.getLocation(), arg, 1.0f, 1.0f);
                        break;
                    case "world": {
                        WorldsModule worlds = core.modules().get(WorldsModule.class);
                        if (worlds == null || !worlds.teleport(p, arg)) {
                            p.sendMessage(color("&cThat world isn't available right now."));
                        }
                        break;
                    }
                    case "lobby": {
                        LobbyModule lobby = core.modules().get(LobbyModule.class);
                        if (lobby == null || !lobby.teleportToLobby(p)) {
                            p.sendMessage(color("&cThe lobby isn't available right now."));
                        }
                        break;
                    }
                    default:
                        getLogger().warning("[menu] unknown action type: [" + type + "]");
                }
            }
        });
    }
}
