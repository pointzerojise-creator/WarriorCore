package com.warrior.warriorcore.lifesteal.commands;

import com.warrior.warriorcore.Util;
import com.warrior.warriorcore.lifesteal.HeartManager;
import com.warrior.warriorcore.lifesteal.ItemManager;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** /warriorlifesteal (alias /wls) - admin tools. */
public class WarriorlifestealCommand implements TabExecutor {

    private static final List<String> SUBS = List.of("reload", "set", "add", "remove", "give", "revive", "info");

    private final LifestealModule plugin;

    public WarriorlifestealCommand(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("warriorlifesteal.admin")) {
            sender.sendMessage(plugin.msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(plugin.msg("admin-usage"));
            return true;
        }

        HeartManager hm = plugin.hearts();
        String sub = args[0].toLowerCase();

        switch (sub) {
            case "reload":
                plugin.reload();
                sender.sendMessage(plugin.msg("reloaded"));
                return true;

            case "info": {
                if (args.length < 2) { sender.sendMessage(plugin.msg("admin-usage")); return true; }
                UUID id = plugin.findPlayer(args[1]);
                if (id == null) { sender.sendMessage(plugin.msg("player-not-found")); return true; }
                sender.sendMessage(plugin.msg("hearts-other",
                        "player", hm.nameOf(id), "hearts", String.valueOf(hm.getHearts(id)))
                        + (hm.isEliminated(id) ? plugin.color(" &4(eliminated)") : ""));
                return true;
            }

            case "set":
            case "add":
            case "remove": {
                if (args.length < 3) { sender.sendMessage(plugin.msg("admin-usage")); return true; }
                UUID id = plugin.findPlayer(args[1]);
                if (id == null) { sender.sendMessage(plugin.msg("player-not-found")); return true; }
                int n;
                try {
                    n = Integer.parseInt(args[2]);
                } catch (NumberFormatException ex) {
                    sender.sendMessage(plugin.msg("invalid-number"));
                    return true;
                }
                int current = hm.getHearts(id);
                int target = sub.equals("set") ? n : sub.equals("add") ? current + n : current - n;
                target = Math.max(0, Math.min(target, hm.maxHearts()));

                boolean wasEliminated = hm.isEliminated(id);
                if (wasEliminated && target > 0) {
                    hm.revive(id, target);
                } else if (target == 0) {
                    hm.eliminate(id);
                } else {
                    hm.setHearts(id, target);
                    Player online = Bukkit.getPlayer(id);
                    if (online != null) plugin.applyState(online);
                }
                sender.sendMessage(plugin.msg("hearts-set",
                        "player", hm.nameOf(id), "hearts", String.valueOf(target)));
                return true;
            }

            case "give": {
                if (args.length < 3) { sender.sendMessage(plugin.msg("admin-usage")); return true; }
                String itemId = args[1].toLowerCase();
                if (!itemId.equals(ItemManager.HEART) && !itemId.equals(ItemManager.REVIVE)) {
                    sender.sendMessage(plugin.msg("unknown-item"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[2]);
                if (target == null) { sender.sendMessage(plugin.msg("player-not-found")); return true; }
                int amount = 1;
                if (args.length > 3) {
                    try {
                        amount = Integer.parseInt(args[3]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(plugin.msg("invalid-number"));
                        return true;
                    }
                }
                if (amount < 1 || amount > 64) { sender.sendMessage(plugin.msg("invalid-number")); return true; }
                ItemStack stack = plugin.items().build(itemId, amount);
                if (stack == null) { sender.sendMessage(plugin.msg("unknown-item")); return true; }
                Map<Integer, ItemStack> left = target.getInventory().addItem(stack);
                for (ItemStack extra : left.values()) {
                    target.getWorld().dropItemNaturally(target.getLocation(), extra);
                }
                sender.sendMessage(plugin.msg("item-given",
                        "amount", String.valueOf(amount), "item", itemId, "player", target.getName()));
                return true;
            }

            case "revive": {
                if (args.length < 2) { sender.sendMessage(plugin.msg("admin-usage")); return true; }
                UUID id = plugin.findPlayer(args[1]);
                if (id == null) { sender.sendMessage(plugin.msg("player-not-found")); return true; }
                if (!hm.isEliminated(id)) {
                    sender.sendMessage(plugin.msg("revive-not-eliminated", "player", hm.nameOf(id)));
                    return true;
                }
                int hearts = plugin.getConfig().getInt("elimination.revive-hearts", 3);
                if (args.length > 2) {
                    try {
                        hearts = Integer.parseInt(args[2]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(plugin.msg("invalid-number"));
                        return true;
                    }
                }
                hm.revive(id, hearts);
                sender.sendMessage(plugin.msg("revived-sender", "player", hm.nameOf(id)));
                return true;
            }

            default:
                sender.sendMessage(plugin.msg("admin-usage"));
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("warriorlifesteal.admin")) return List.of();
        if (args.length == 1) return Util.match(SUBS, args[0]);

        String sub = args[0].toLowerCase();
        if (args.length == 2) {
            switch (sub) {
                case "give":
                    return Util.match(List.of("heart", "revive"), args[1]);
                case "set": case "add": case "remove": case "info":
                    return Util.match(plugin.hearts().knownNames(), args[1]);
                case "revive":
                    return Util.match(plugin.hearts().eliminatedNames(), args[1]);
                default:
                    return List.of();
            }
        }
        if (args.length == 3 && sub.equals("give")) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return Util.match(names, args[2]);
        }
        return List.of();
    }
}
