package com.warrior.warriorcore.worlds;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.generator.WorldInfo;

import java.util.Random;

/** Empty world with a small stone platform at 8,63,8 so players have somewhere to stand. */
public class VoidGenerator extends ChunkGenerator {

    @Override
    public void generateSurface(WorldInfo worldInfo, Random random, int chunkX, int chunkZ, ChunkData chunkData) {
        if (chunkX == 0 && chunkZ == 0) {
            for (int x = 6; x <= 10; x++) {
                for (int z = 6; z <= 10; z++) {
                    chunkData.setBlock(x, 63, z, Material.STONE);
                }
            }
        }
    }

    @Override
    public Location getFixedSpawnLocation(World world, Random random) {
        return new Location(world, 8.5, 64, 8.5);
    }
}
