package com.warrior.warriorcore.worlds;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

/** Create, load and manage worlds with per-world gamemode / pvp / difficulty / keepInventory. */
public class WorldsModule extends CoreModule {

    public static final List<String> TYPES = List.of("normal", "flat", "void", "amplified", "large_biomes");
    public static final List<String> ENVS = List.of("normal", "nether", "the_end");
    public static final List<String> KEYS = List.of("gamemode", "pvp", "difficulty", "keepinventory");

    private File dataFile;
    private YamlConfiguration data;

    public WorldsModule(WarriorCore core) {
        super(core, "worlds");
    }

    @Override
    public void enable() {
        dataFile = new File(core.getDataFolder(), "worlds-data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        ConfigurationSection ws = data.getConfigurationSection("worlds");
        if (ws != null) {
            for (String name : new ArrayList<>(ws.getKeys(false))) {
                if (loadWorld(name) == null) {
                    getLogger().warning("[worlds] could not load world '" + name + "'");
                }
            }
        }

        WorldsCommand handler = new WorldsCommand(this);
        command("mw", handler);
        command("play", handler);
        listen(new WorldsListener(this));
    }

    @Override
    public void reload() {
        loadConfig();
    }

    // ------------------------------------------------------------------ lookup

    public World findWorld(String name) {
        for (World w : Bukkit.getWorlds()) {
            if (w.getName().equalsIgnoreCase(name)) return w;
        }
        return null;
    }

    public boolean isManaged(String name) {
        return data.contains("worlds." + realName(name));
    }

    public List<String> managedNames() {
        ConfigurationSection ws = data.getConfigurationSection("worlds");
        return ws == null ? new ArrayList<>() : new ArrayList<>(ws.getKeys(false));
    }

    public List<String> worldNames() {
        List<String> out = new ArrayList<>();
        for (World w : Bukkit.getWorlds()) out.add(w.getName());
        return out;
    }

    public boolean isPublic(String name) {
        for (String s : cfg().getStringList("public-worlds")) {
            if (s.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    private String realName(String name) {
        World w = findWorld(name);
        return w != null ? w.getName() : name;
    }

    // ---------------------------------------------------------------- creating

    /** Creates a new world and remembers it. Returns null if creation failed. */
    public World createWorld(String name, String type, String env, Long seed) {
        String base = "worlds." + name;
        data.set(base + ".type", type.toLowerCase());
        data.set(base + ".env", env.toLowerCase());
        if (seed != null) data.set(base + ".seed", seed);
        World w = loadWorld(name);
        if (w == null) {
            data.set(base, null);
        }
        save();
        return w;
    }

    /** Loads an existing world folder using default settings and remembers it. */
    public World importWorld(String name) {
        String base = "worlds." + name;
        if (!data.contains(base)) {
            data.set(base + ".type", "normal");
            data.set(base + ".env", "normal");
        }
        World w = loadWorld(name);
        if (w == null) data.set(base, null);
        save();
        return w;
    }

    /** Loads (or finds) a remembered world and applies its settings. */
    public World loadWorld(String name) {
        World existing = findWorld(name);
        if (existing != null) {
            applySettings(existing);
            return existing;
        }
        String base = "worlds." + name;
        String type = data.getString(base + ".type", "normal").toLowerCase();
        String env = data.getString(base + ".env", "normal").toLowerCase();

        WorldCreator wc = new WorldCreator(name);
        switch (env) {
            case "nether": wc.environment(World.Environment.NETHER); break;
            case "the_end": case "end": wc.environment(World.Environment.THE_END); break;
            default: wc.environment(World.Environment.NORMAL);
        }
        switch (type) {
            case "flat": wc.type(WorldType.FLAT); break;
            case "amplified": wc.type(WorldType.AMPLIFIED); break;
            case "large_biomes": wc.type(WorldType.LARGE_BIOMES); break;
            case "void": wc.generator(new VoidGenerator()); break;
            default: wc.type(WorldType.NORMAL);
        }
        if (data.contains(base + ".seed")) wc.seed(data.getLong(base + ".seed"));

        World w;
        try {
            w = wc.createWorld();
        } catch (Exception ex) {
            getLogger().warning("[worlds] createWorld failed for " + name + ": " + ex.getMessage());
            return null;
        }
        if (w != null) applySettings(w);
        return w;
    }

    /** Applies pvp / difficulty / keepInventory / custom spawn from worlds-data.yml. */
    public void applySettings(World w) {
        String base = "worlds." + w.getName();
        if (!data.contains(base)) return;

        w.setPVP(data.getBoolean(base + ".pvp", true));
        try {
            w.setDifficulty(Difficulty.valueOf(data.getString(base + ".difficulty", "NORMAL").toUpperCase()));
        } catch (IllegalArgumentException ignored) {
            // keep current difficulty
        }
        w.setGameRule(GameRule.KEEP_INVENTORY, data.getBoolean(base + ".keep-inventory", false));

        if (data.contains(base + ".spawn.x")) {
            w.setSpawnLocation(data.getInt(base + ".spawn.x"), data.getInt(base + ".spawn.y"), data.getInt(base + ".spawn.z"));
        }
    }

    // ---------------------------------------------------------------- settings

    /** Returns null on success, or a message key describing the problem. */
    public String setSetting(String worldName, String key, String value) {
        World w = findWorld(worldName);
        if (w == null) return "not-found";
        String base = "worlds." + w.getName();
        if (!data.contains(base)) {
            data.set(base + ".type", "normal");
            data.set(base + ".env", w.getEnvironment().name().toLowerCase());
        }
        String v = value.toLowerCase();
        switch (key.toLowerCase()) {
            case "gamemode":
                if (v.equals("none") || v.equals("off")) {
                    data.set(base + ".gamemode", null);
                } else {
                    try {
                        data.set(base + ".gamemode", GameMode.valueOf(v.toUpperCase()).name());
                    } catch (IllegalArgumentException ex) {
                        return "invalid-value";
                    }
                }
                break;
            case "pvp":
                if (!v.equals("true") && !v.equals("false")) return "invalid-value";
                data.set(base + ".pvp", Boolean.parseBoolean(v));
                break;
            case "keepinventory":
                if (!v.equals("true") && !v.equals("false")) return "invalid-value";
                data.set(base + ".keep-inventory", Boolean.parseBoolean(v));
                break;
            case "difficulty":
                try {
                    data.set(base + ".difficulty", Difficulty.valueOf(v.toUpperCase()).name());
                } catch (IllegalArgumentException ex) {
                    return "invalid-value";
                }
                break;
            default:
                return "setting-invalid";
        }
        applySettings(w);
        save();
        return null;
    }

    /** Forced gamemode for this world, or null if none is configured. */
    public GameMode gamemodeOf(World w) {
        String gm = data.getString("worlds." + w.getName() + ".gamemode");
        if (gm == null || gm.isEmpty()) return null;
        try {
            return GameMode.valueOf(gm.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    // ------------------------------------------------------------------ spawn

    public void setSpawn(Location loc) {
        World w = loc.getWorld();
        if (w == null) return;
        String base = "worlds." + w.getName();
        if (!data.contains(base)) {
            data.set(base + ".type", "normal");
            data.set(base + ".env", w.getEnvironment().name().toLowerCase());
        }
        data.set(base + ".spawn.x", loc.getBlockX());
        data.set(base + ".spawn.y", loc.getBlockY());
        data.set(base + ".spawn.z", loc.getBlockZ());
        data.set(base + ".spawn.yaw", (double) loc.getYaw());
        data.set(base + ".spawn.pitch", (double) loc.getPitch());
        w.setSpawnLocation(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        save();
    }

    public Location spawnOf(World w) {
        String base = "worlds." + w.getName() + ".spawn";
        if (data.contains(base + ".x")) {
            return new Location(w, data.getInt(base + ".x") + 0.5, data.getInt(base + ".y"), data.getInt(base + ".z") + 0.5,
                    (float) data.getDouble(base + ".yaw", 0.0), (float) data.getDouble(base + ".pitch", 0.0));
        }
        return w.getSpawnLocation().add(0.5, 0, 0.5);
    }

    /** Teleports the player to the world's spawn. Returns false if the world doesn't exist. */
    public boolean teleport(Player p, String worldName) {
        World w = findWorld(worldName);
        if (w == null) return false;
        p.teleport(spawnOf(w));
        return true;
    }

    // ------------------------------------------------------------------ delete

    public boolean deleteWorld(String name) {
        World w = findWorld(name);
        if (w == null) return false;
        World fallback = null;
        for (World other : Bukkit.getWorlds()) {
            if (!other.equals(w)) { fallback = other; break; }
        }
        if (fallback == null) return false;
        for (Player p : new ArrayList<>(w.getPlayers())) {
            p.teleport(spawnOf(fallback));
        }
        File folder = w.getWorldFolder();
        if (!Bukkit.unloadWorld(w, false)) return false;
        data.set("worlds." + w.getName(), null);
        save();
        return deleteFolder(folder.toPath());
    }

    private boolean deleteFolder(Path root) {
        try (Stream<Path> walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(path -> {
                try {
                    Files.delete(path);
                } catch (IOException ignored) {
                    // reported by the folder still existing below
                }
            });
        } catch (IOException ex) {
            return false;
        }
        return !Files.exists(root);
    }

    private void save() {
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("[worlds] could not save worlds-data.yml: " + ex.getMessage());
        }
    }
}
