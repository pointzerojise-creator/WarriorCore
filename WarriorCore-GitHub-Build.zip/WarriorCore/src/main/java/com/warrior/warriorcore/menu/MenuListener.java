package com.warrior.warriorcore.menu;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.inventory.Inventory;

public class MenuListener implements Listener {

    private final MenuModule menus;

    public MenuListener(MenuModule menus) {
        this.menus = menus;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder holder)) return;
        e.setCancelled(true);

        if (e.getClickedInventory() != top) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        MenuModule.Menu menu = menus.menu(holder.menuId());
        if (menu == null) return;
        MenuModule.MenuItem item = menu.items.get(e.getSlot());
        if (item == null || item.actions.isEmpty()) return;
        menus.runActions(p, item.actions);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof MenuHolder) {
            e.setCancelled(true);
        }
    }

    /** Lets players type the menu's open-command, e.g. /gamemodes. */
    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String message = e.getMessage();
        if (message.length() < 2) return;
        String first = message.substring(1).split(" ")[0];
        String id = menus.menuForCommand(first);
        if (id == null) return;

        e.setCancelled(true);
        Player p = e.getPlayer();
        if (!p.hasPermission("warriorcore.menu.use")) {
            p.sendMessage(menus.msg("no-permission"));
            return;
        }
        menus.open(p, id);
    }
}
