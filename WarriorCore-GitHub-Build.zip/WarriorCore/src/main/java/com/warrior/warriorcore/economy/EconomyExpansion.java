package com.warrior.warriorcore.economy;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

import java.util.List;
import java.util.UUID;

/** PlaceholderAPI: %warrioreconomy_balance%, _balance_formatted, _top_N_name, _top_N_balance */
public class EconomyExpansion extends PlaceholderExpansion {

    private final EconomyModule economy;

    public EconomyExpansion(EconomyModule economy) {
        this.economy = economy;
    }

    @Override
    public String getIdentifier() {
        return "warrioreconomy";
    }

    @Override
    public String getAuthor() {
        return "Warrior";
    }

    @Override
    public String getVersion() {
        return economy.core().getDescription().getVersion();
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        String p = params.toLowerCase();

        if (p.startsWith("top_")) {
            String[] parts = p.split("_");
            if (parts.length != 3) return null;
            int n;
            try {
                n = Integer.parseInt(parts[1]);
            } catch (NumberFormatException ex) {
                return null;
            }
            boolean wantName = parts[2].equals("name");
            if (!wantName && !parts[2].equals("balance")) return null;
            List<UUID> top = economy.top();
            if (n < 1 || n > top.size()) return wantName ? "-" : economy.format(0L);
            UUID id = top.get(n - 1);
            return wantName ? economy.nameOf(id) : economy.format(economy.getBalance(id));
        }

        if (player == null) return "";
        UUID id = player.getUniqueId();
        switch (p) {
            case "balance":
                return economy.plain(economy.getBalance(id));
            case "balance_formatted":
                return economy.format(economy.getBalance(id));
            default:
                return null;
        }
    }
}
