package com.warrior.warriorcore.lifesteal;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.RecipeChoice;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

/** Builds the custom items (heart, revive) from config.yml and registers their crafting recipes. */
public class ItemManager {

    public static final String HEART = "heart";
    public static final String REVIVE = "revive";

    private final LifestealModule plugin;
    private final NamespacedKey idKey;
    private final List<NamespacedKey> recipeKeys = new ArrayList<>();

    public ItemManager(LifestealModule plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin.core(), "item_id");
    }

    public List<NamespacedKey> getRecipeKeys() {
        return recipeKeys;
    }

    /** Builds the item defined at items.<id> in config.yml, or null if it is not defined. */
    public ItemStack build(String id, int amount) {
        ConfigurationSection s = plugin.getConfig().getConfigurationSection("items." + id);
        if (s == null) return null;

        Material mat = Material.matchMaterial(s.getString("material", "NETHER_STAR"));
        if (mat == null || !mat.isItem() || mat.isAir()) {
            plugin.getLogger().warning("items." + id + ".material is not a valid item - using NETHER_STAR");
            mat = Material.NETHER_STAR;
        }

        ItemStack stack = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;

        meta.setDisplayName(plugin.color(s.getString("name", id)));

        List<String> lore = new ArrayList<>();
        for (String line : s.getStringList("lore")) lore.add(plugin.color(line));
        if (!lore.isEmpty()) meta.setLore(lore);

        int cmd = s.getInt("custom-model-data", 0);
        if (cmd > 0) {
            try {
                meta.setCustomModelData(cmd);
            } catch (LinkageError ignored) {
                plugin.getLogger().warning("custom-model-data is not supported on this server version.");
            }
        }

        if (s.getBoolean("glow", false)) {
            Enchantment glowEnchant = Enchantment.getByKey(NamespacedKey.minecraft("unbreaking"));
            if (glowEnchant != null) {
                meta.addEnchant(glowEnchant, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
        }

        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        stack.setItemMeta(meta);
        return stack;
    }

    /** Returns "heart", "revive" (the config id) or null if this is not one of our items. */
    public String typeOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    // --------------------------------------------------------------- recipes

    public void unregisterRecipes() {
        for (NamespacedKey key : recipeKeys) {
            Bukkit.removeRecipe(key);
        }
        recipeKeys.clear();
    }

    /** (Re)registers the shaped recipes from items.<id>.recipe. Safe to call on reload. */
    public void registerRecipes() {
        unregisterRecipes();
        for (String id : new String[]{HEART, REVIVE}) {
            registerRecipe(id);
        }
    }

    private void registerRecipe(String id) {
        ConfigurationSection rs = plugin.getConfig().getConfigurationSection("items." + id + ".recipe");
        if (rs == null || !rs.getBoolean("enabled", true)) return;

        List<String> shape = rs.getStringList("shape");
        ConfigurationSection ing = rs.getConfigurationSection("ingredients");
        if (shape.isEmpty() || shape.size() > 3 || ing == null) {
            plugin.getLogger().warning("Recipe for '" + id + "' skipped: shape needs 1-3 rows and an ingredients section.");
            return;
        }
        for (String row : shape) {
            if (row.isEmpty() || row.length() > 3) {
                plugin.getLogger().warning("Recipe for '" + id + "' skipped: each shape row must be 1-3 characters.");
                return;
            }
        }

        ItemStack result = build(id, rs.getInt("amount", 1));
        if (result == null) return;

        NamespacedKey key = new NamespacedKey(plugin.core(), id + "_recipe");
        ShapedRecipe recipe = new ShapedRecipe(key, result);
        recipe.shape(shape.toArray(new String[0]));

        List<Character> used = new ArrayList<>();
        for (String row : shape) {
            for (char c : row.toCharArray()) {
                if (c != ' ' && !used.contains(c)) used.add(c);
            }
        }
        for (char c : used) {
            String value = ing.getString(String.valueOf(c));
            if (value == null) {
                plugin.getLogger().warning("Recipe for '" + id + "' skipped: no ingredient defined for '" + c + "'.");
                return;
            }
            RecipeChoice choice = parseChoice(value);
            if (choice == null) {
                plugin.getLogger().warning("Recipe for '" + id + "' skipped: unknown ingredient '" + value + "'.");
                return;
            }
            recipe.setIngredient(c, choice);
        }

        try {
            if (Bukkit.addRecipe(recipe)) {
                recipeKeys.add(key);
            }
        } catch (IllegalStateException | IllegalArgumentException ex) {
            plugin.getLogger().warning("Could not register recipe for '" + id + "': " + ex.getMessage());
        }
    }

    private RecipeChoice parseChoice(String value) {
        String v = value.trim();
        if (v.toLowerCase().startsWith("item:")) {
            ItemStack custom = build(v.substring(5).trim(), 1);
            return custom == null ? null : new RecipeChoice.ExactChoice(custom);
        }
        Material m = Material.matchMaterial(v);
        if (m == null || !m.isItem() || m.isAir()) return null;
        return new RecipeChoice.MaterialChoice(m);
    }
}
