package com.warrior.warriorcore.worlds;

import com.warrior.warriorcore.Util;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;

/** Handles /mw (admin) and /play (public worlds). */
public class WorldsCommand implements TabExecutor {

    private final WorldsModule module;

    public WorldsCommand(WorldsModule module) {
        this.module = module;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("play")) {
            return play(sender, args);
        }
        return admin(sender, args);
    }

    // ------------------------------------------------------------------ /play

    private boolean play(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(module.msg("players-only"));
            return true;
        }
        if (args.length < 1) {
            p.sendMessage(module.msg("not-found", "world", "?"));
            return true;
        }
        String name = args[0];
        if (!module.isPublic(name) && !p.hasPermission("warriorcore.worlds.admin")) {
            p.sendMessage(module.msg("play-denied"));
            return true;
        }
        World w = module.findWorld(name);
        if (w == null) {
            p.sendMessage(module.msg("not-found", "world", name));
            return true;
        }
        module.teleport(p, w.getName());
        p.sendMessage(module.msg("teleported", "world", w.getName()));
        return true;
    }

    // -------------------------------------------------------------------- /mw

    private boolean admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("warriorcore.worlds.admin")) {
            sender.sendMessage(module.msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage(module.msg("admin-usage"));
            return true;
        }
        String sub = args[0].toLowerCase();
        switch (sub) {
            case "create": {
                if (args.length < 2) { sender.sendMessage(module.msg("admin-usage")); return true; }
                String name = args[1];
                if (module.findWorld(name) != null) {
                    sender.sendMessage(module.msg("already-exists", "world", name));
                    return true;
                }
                String type = args.length > 2 ? args[2].toLowerCase() : "normal";
                String env = args.length > 3 ? args[3].toLowerCase() : "normal";
                if (!WorldsModule.TYPES.contains(type) || !WorldsModule.ENVS.contains(env)) {
                    sender.sendMessage(module.msg("admin-usage"));
                    return true;
                }
                Long seed = null;
                if (args.length > 4) {
                    try {
                        seed = Long.parseLong(args[4]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(module.msg("invalid-value"));
                        return true;
                    }
                }
                sender.sendMessage(module.color("&7Creating world... (the server may lag for a moment)"));
                World w = module.createWorld(name, type, env, seed);
                sender.sendMessage(w != null ? module.msg("created", "world", name) : module.msg("create-failed", "world", name));
                return true;
            }
            case "import": {
                if (args.length < 2) { sender.sendMessage(module.msg("admin-usage")); return true; }
                String name = args[1];
                if (module.findWorld(name) != null) {
                    sender.sendMessage(module.msg("already-exists", "world", name));
                    return true;
                }
                if (!new java.io.File(Bukkit.getWorldContainer(), name).isDirectory()) {
                    sender.sendMessage(module.msg("no-folder", "world", name));
                    return true;
                }
                World w = module.importWorld(name);
                sender.sendMessage(w != null ? module.msg("imported", "world", name) : module.msg("create-failed", "world", name));
                return true;
            }
            case "tp": {
                if (args.length < 2) { sender.sendMessage(module.msg("admin-usage")); return true; }
                World w = module.findWorld(args[1]);
                if (w == null) { sender.sendMessage(module.msg("not-found", "world", args[1])); return true; }
                Player target;
                if (args.length > 2) {
                    target = Bukkit.getPlayerExact(args[2]);
                    if (target == null) { sender.sendMessage(module.msg("player-not-found")); return true; }
                } else if (sender instanceof Player self) {
                    target = self;
                } else {
                    sender.sendMessage(module.msg("players-only"));
                    return true;
                }
                module.teleport(target, w.getName());
                if (target == sender) {
                    target.sendMessage(module.msg("teleported", "world", w.getName()));
                } else {
                    sender.sendMessage(module.msg("teleported-other", "player", target.getName(), "world", w.getName()));
                }
                return true;
            }
            case "list": {
                sender.sendMessage(module.msg("list-header"));
                for (World w : Bukkit.getWorlds()) {
                    String type = module.isManaged(w.getName()) ? " &a*" : "";
                    sender.sendMessage(module.color(module.fill(module.cfg().getString("messages.list-line", "%world%"),
                            "world", w.getName(), "env", w.getEnvironment().name().toLowerCase(),
                            "type", String.valueOf(w.getWorldType()).toLowerCase(), "managed", type)));
                }
                return true;
            }
            case "setspawn": {
                if (!(sender instanceof Player p)) { sender.sendMessage(module.msg("players-only")); return true; }
                module.setSpawn(p.getLocation());
                sender.sendMessage(module.msg("spawn-set", "world", p.getWorld().getName()));
                return true;
            }
            case "set": {
                if (args.length < 4) { sender.sendMessage(module.msg("admin-usage")); return true; }
                String result = module.setSetting(args[1], args[2], args[3]);
                if (result == null) {
                    sender.sendMessage(module.msg("setting-changed", "key", args[2], "world", args[1], "value", args[3]));
                } else {
                    sender.sendMessage(module.msg(result, "world", args[1]));
                }
                return true;
            }
            case "delete": {
                if (args.length < 2) { sender.sendMessage(module.msg("admin-usage")); return true; }
                String name = args[1];
                if (module.findWorld(name) == null) { sender.sendMessage(module.msg("not-found", "world", name)); return true; }
                if (args.length < 3 || !args[2].equalsIgnoreCase("confirm")) {
                    sender.sendMessage(module.msg("delete-confirm", "world", name));
                    return true;
                }
                boolean ok = module.deleteWorld(name);
                sender.sendMessage(ok ? module.msg("deleted", "world", name) : module.msg("delete-failed", "world", name));
                return true;
            }
            default:
                sender.sendMessage(module.msg("admin-usage"));
                return true;
        }
    }

    // ------------------------------------------------------------ tab complete

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (command.getName().equalsIgnoreCase("play")) {
            if (args.length == 1) return Util.match(module.worldNames(), args[0]);
            return List.of();
        }
        if (!sender.hasPermission("warriorcore.worlds.admin")) return List.of();
        if (args.length == 1) {
            return Util.match(List.of("create", "import", "tp", "list", "setspawn", "set", "delete"), args[0]);
        }
        String sub = args[0].toLowerCase();
        if (args.length == 2 && (sub.equals("tp") || sub.equals("set") || sub.equals("delete"))) {
            return Util.match(module.worldNames(), args[1]);
        }
        if (sub.equals("create")) {
            if (args.length == 3) return Util.match(WorldsModule.TYPES, args[2]);
            if (args.length == 4) return Util.match(WorldsModule.ENVS, args[3]);
        }
        if (sub.equals("set")) {
            if (args.length == 3) return Util.match(WorldsModule.KEYS, args[2]);
            if (args.length == 4) {
                switch (args[2].toLowerCase()) {
                    case "gamemode": return Util.match(List.of("survival", "creative", "adventure", "spectator", "none"), args[3]);
                    case "pvp": case "keepinventory": return Util.match(List.of("true", "false"), args[3]);
                    case "difficulty": return Util.match(List.of("peaceful", "easy", "normal", "hard"), args[3]);
                    default: return List.of();
                }
            }
        }
        if (sub.equals("tp") && args.length == 3) return Util.match(Util.onlineNames(), args[2]);
        if (sub.equals("delete") && args.length == 3) return Util.match(List.of("confirm"), args[2]);
        return List.of();
    }
}
