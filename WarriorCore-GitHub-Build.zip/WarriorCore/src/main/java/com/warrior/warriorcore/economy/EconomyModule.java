package com.warrior.warriorcore.economy;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Money stored as whole cents (long) so there are no floating point errors. */
public class EconomyModule extends CoreModule {

    private final Map<UUID, Long> balances = new ConcurrentHashMap<>();
    private final Map<UUID, String> names = new ConcurrentHashMap<>();
    private final Object fileLock = new Object();
    private File file;
    private BukkitTask autosave;
    private List<UUID> topCache = new ArrayList<>();
    private long topTime = 0L;

    public EconomyModule(WarriorCore core) {
        super(core, "economy");
    }

    @Override
    public void enable() {
        file = new File(core.getDataFolder(), "economy-data.yml");
        load();

        for (String name : new String[]{"balance", "pay", "baltop", "eco"}) {
            command(name, new EconomyCommand(this));
        }
        listen(new EconomyListener(this));

        if (core.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                new EconomyExpansion(this).register();
                getLogger().info("[economy] PlaceholderAPI found - %warrioreconomy_...% placeholders registered.");
            } catch (Exception | LinkageError ex) {
                getLogger().warning("[economy] Could not register PlaceholderAPI expansion: " + ex);
            }
        }

        autosave = Bukkit.getScheduler().runTaskTimer(core, this::saveAsync, 20L * 120, 20L * 120);
        for (Player p : Bukkit.getOnlinePlayers()) remember(p.getUniqueId(), p.getName());
    }

    @Override
    public void disable() {
        if (autosave != null) autosave.cancel();
        saveSync();
    }

    // -------------------------------------------------------------------- API

    public long startCents() {
        return Math.max(0L, Math.round(cfg().getDouble("start-balance", 100.0) * 100.0));
    }

    public long minPayCents() {
        return Math.max(1L, Math.round(cfg().getDouble("min-pay", 1.0) * 100.0));
    }

    public long getBalance(UUID id) {
        return balances.getOrDefault(id, startCents());
    }

    public boolean has(UUID id, long cents) {
        return getBalance(id) >= cents;
    }

    public synchronized void deposit(UUID id, long cents) {
        long cur = getBalance(id);
        long next = cur + cents;
        balances.put(id, next < cur ? Long.MAX_VALUE : next);
    }

    /** Takes money if the player has enough. Returns false (and changes nothing) otherwise. */
    public synchronized boolean withdraw(UUID id, long cents) {
        long cur = getBalance(id);
        if (cur < cents) return false;
        balances.put(id, cur - cents);
        return true;
    }

    public synchronized void set(UUID id, long cents) {
        balances.put(id, Math.max(0L, cents));
    }

    public String format(long cents) {
        String symbol = cfg().getString("currency-symbol", "$");
        return symbol + String.format(Locale.US, "%,.2f", BigDecimal.valueOf(cents, 2));
    }

    public String plain(long cents) {
        return String.format(Locale.US, "%.2f", BigDecimal.valueOf(cents, 2));
    }

    /** "12.5" -> 1250 cents. Returns null if invalid (or zero/negative unless allowZero). */
    public Long parse(String text, boolean allowZero) {
        try {
            BigDecimal bd = new BigDecimal(text.replace(",", "")).setScale(2, RoundingMode.DOWN);
            if (bd.signum() < 0 || (bd.signum() == 0 && !allowZero)) return null;
            return bd.movePointRight(2).longValueExact();
        } catch (NumberFormatException | ArithmeticException ex) {
            return null;
        }
    }

    // ---------------------------------------------------------------- players

    public void remember(UUID id, String name) {
        names.put(id, name);
        balances.putIfAbsent(id, startCents());
    }

    public String nameOf(UUID id) {
        String n = names.get(id);
        return n == null ? "Unknown" : n;
    }

    public UUID findByName(String name) {
        for (Map.Entry<UUID, String> e : names.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    /** Online player by exact name, otherwise a known (previously joined) player. */
    public UUID findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        return findByName(name);
    }

    public List<String> knownNames() {
        return new ArrayList<>(names.values());
    }

    /** Players sorted by balance (richest first). Cached for 5 seconds. */
    public synchronized List<UUID> top() {
        long now = System.currentTimeMillis();
        if (now - topTime > 5000L) {
            List<UUID> ids = new ArrayList<>(balances.keySet());
            ids.sort((a, b) -> {
                int c = Long.compare(getBalance(b), getBalance(a));
                return c != 0 ? c : nameOf(a).compareToIgnoreCase(nameOf(b));
            });
            topCache = ids;
            topTime = now;
        }
        return topCache;
    }

    // ------------------------------------------------------------ persistence

    private void load() {
        core.getDataFolder().mkdirs();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection players = y.getConfigurationSection("players");
        if (players == null) return;
        for (String key : players.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            balances.put(id, players.getLong(key + ".cents", startCents()));
            String name = players.getString(key + ".name");
            if (name != null) names.put(id, name);
        }
        getLogger().info("[economy] Loaded " + balances.size() + " account(s).");
    }

    public void saveSync() {
        write(new HashMap<>(balances), new HashMap<>(names));
    }

    private void saveAsync() {
        final Map<UUID, Long> b = new HashMap<>(balances);
        final Map<UUID, String> n = new HashMap<>(names);
        Bukkit.getScheduler().runTaskAsynchronously(core, () -> write(b, n));
    }

    private void write(Map<UUID, Long> b, Map<UUID, String> n) {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Long> e : b.entrySet()) {
            String base = "players." + e.getKey();
            y.set(base + ".cents", e.getValue());
            String name = n.get(e.getKey());
            if (name != null) y.set(base + ".name", name);
        }
        synchronized (fileLock) {
            File tmp = new File(core.getDataFolder(), "economy-data.yml.tmp");
            try {
                y.save(tmp);
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                getLogger().warning("[economy] Could not save economy-data.yml: " + ex.getMessage());
            }
        }
    }
}
