package com.warrior.warriorcore.shop;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import com.warrior.warriorcore.economy.EconomyModule;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** GUI shop driven by modules/shop.yml. Uses the economy module for money. */
public class ShopModule extends CoreModule {

    public static class ShopItem {
        public final Material material;
        public final long buy;   // cents, -1 = not for sale
        public final long sell;  // cents, -1 = can't be sold

        public ShopItem(Material material, long buy, long sell) {
            this.material = material;
            this.buy = buy;
            this.sell = sell;
        }
    }

    public static class Category {
        public final String id;
        public final String name;
        public final Material icon;
        public final int slot;
        public final List<ShopItem> items = new ArrayList<>();

        public Category(String id, String name, Material icon, int slot) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.slot = slot;
        }
    }

    private EconomyModule economy;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final Map<Material, ShopItem> byMaterial = new HashMap<>();

    public ShopModule(WarriorCore core) {
        super(core, "shop");
    }

    @Override
    public void enable() {
        economy = core.modules().get(EconomyModule.class);
        if (economy == null) {
            getLogger().warning("[shop] The shop needs the economy module - leaving the shop off.");
            return;
        }
        load();
        ShopCommand handler = new ShopCommand(this);
        command("shop", handler);
        command("sell", handler);
        listen(new ShopListener(this));
    }

    @Override
    public void reload() {
        loadConfig();
        if (economy != null) load();
    }

    // ------------------------------------------------------------------ config

    private void load() {
        categories.clear();
        byMaterial.clear();
        var section = cfg().getConfigurationSection("categories");
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            var cs = section.getConfigurationSection(id);
            if (cs == null) continue;
            Material icon = Material.matchMaterial(cs.getString("icon", "CHEST"));
            if (icon == null || !icon.isItem()) icon = Material.CHEST;
            Category cat = new Category(id, cs.getString("name", id), icon, cs.getInt("slot", categories.size()));

            for (Map<?, ?> m : cs.getMapList("items")) {
                if (cat.items.size() >= 45) break;
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || !mat.isItem() || mat.isAir()) {
                    getLogger().warning("[shop] unknown material '" + m.get("material") + "' in category " + id);
                    continue;
                }
                ShopItem item = new ShopItem(mat, cents(m.get("buy")), cents(m.get("sell")));
                cat.items.add(item);
                byMaterial.putIfAbsent(mat, item);
            }
            categories.put(id, cat);
        }
    }

    private long cents(Object value) {
        if (value == null) return -1L;
        try {
            double d = Double.parseDouble(String.valueOf(value));
            return d < 0 ? -1L : Math.round(d * 100.0);
        } catch (NumberFormatException ex) {
            return -1L;
        }
    }

    public Category category(String id) {
        return categories.get(id);
    }

    public Category categoryAtSlot(int slot) {
        for (Category c : categories.values()) {
            if (c.slot == slot) return c;
        }
        return null;
    }

    public ShopItem priceOf(Material material) {
        return byMaterial.get(material);
    }

    // --------------------------------------------------------------------- GUIs

    private ItemStack named(Material mat, String name, List<String> lore) {
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(color(name));
            if (lore != null && !lore.isEmpty()) meta.setLore(lore);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    private ItemStack filler() {
        String name = cfg().getString("filler");
        if (name == null) return null;
        Material mat = Material.matchMaterial(name);
        if (mat == null || !mat.isItem()) return null;
        return named(mat, " ", null);
    }

    public void openMain(Player p) {
        int rows = Math.max(1, Math.min(6, cfg().getInt("rows", 3)));
        ShopHolder holder = new ShopHolder(null);
        Inventory inv = Bukkit.createInventory(holder, rows * 9, color(cfg().getString("title", "&8Shop")));
        holder.setInventory(inv);

        ItemStack fill = filler();
        if (fill != null) {
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, fill);
        }
        for (Category c : categories.values()) {
            if (c.slot >= 0 && c.slot < inv.getSize()) {
                List<String> lore = new ArrayList<>();
                lore.add(color(cfg().getString("gui.category-lore", "&7Click to browse")));
                inv.setItem(c.slot, named(c.icon, c.name, lore));
            }
        }
        p.openInventory(inv);
    }

    public void openCategory(Player p, Category c) {
        ShopHolder holder = new ShopHolder(c.id);
        Inventory inv = Bukkit.createInventory(holder, 54, color(c.name));
        holder.setInventory(inv);

        ItemStack fill = filler();
        if (fill != null) {
            for (int i = 45; i < 54; i++) inv.setItem(i, fill);
        }
        for (int i = 0; i < c.items.size() && i < 45; i++) {
            ShopItem it = c.items.get(i);
            List<String> lore = new ArrayList<>();
            if (it.buy >= 0) {
                lore.add(color(cfg().getString("gui.lore-buy", "&7Buy: &a%price%").replace("%price%", economy.format(it.buy))));
            } else {
                lore.add(color(cfg().getString("gui.lore-no-buy", "&8Not for sale")));
            }
            if (it.sell >= 0) {
                lore.add(color(cfg().getString("gui.lore-sell", "&7Sell: &e%price%").replace("%price%", economy.format(it.sell))));
            } else {
                lore.add(color(cfg().getString("gui.lore-no-sell", "&8Cannot be sold")));
            }
            ItemStack display = new ItemStack(it.material);
            ItemMeta meta = display.getItemMeta();
            if (meta != null) {
                meta.setLore(lore);
                display.setItemMeta(meta);
            }
            inv.setItem(i, display);
        }
        inv.setItem(49, named(Material.ARROW, cfg().getString("gui.back-name", "&cBack"), null));
        p.openInventory(inv);
    }

    // ------------------------------------------------------------ buy and sell

    public void buy(Player p, ShopItem item, int amount) {
        if (item.buy < 0) {
            p.sendMessage(msg("not-for-sale"));
            return;
        }
        long total = item.buy * amount;
        if (!economy.withdraw(p.getUniqueId(), total)) {
            p.sendMessage(msg("not-enough"));
            return;
        }
        Map<Integer, ItemStack> left = p.getInventory().addItem(new ItemStack(item.material, amount));
        for (ItemStack extra : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), extra);
        }
        p.sendMessage(msg("bought", "amount", String.valueOf(amount), "item", nice(item.material), "price", economy.format(total)));
    }

    public void sell(Player p, ShopItem item, int amount) {
        if (item.sell < 0) {
            p.sendMessage(msg("not-sellable"));
            return;
        }
        int removed = removePlain(p, item.material, amount);
        if (removed <= 0) {
            p.sendMessage(msg("nothing-to-sell"));
            return;
        }
        long total = item.sell * removed;
        economy.deposit(p.getUniqueId(), total);
        p.sendMessage(msg("sold", "amount", String.valueOf(removed), "item", nice(item.material), "price", economy.format(total)));
    }

    /** Sells the stack in the player's main hand. */
    public void sellHand(Player p) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            p.sendMessage(msg("nothing-to-sell"));
            return;
        }
        ShopItem item = byMaterial.get(hand.getType());
        if (item == null || item.sell < 0 || hand.hasItemMeta()) {
            p.sendMessage(msg("not-sellable"));
            return;
        }
        int amount = hand.getAmount();
        p.getInventory().setItemInMainHand(null);
        long total = item.sell * amount;
        economy.deposit(p.getUniqueId(), total);
        p.sendMessage(msg("sold", "amount", String.valueOf(amount), "item", nice(item.material), "price", economy.format(total)));
    }

    /** Removes up to 'amount' plain (no name/lore/enchants) items. Returns how many were removed. */
    private int removePlain(Player p, Material mat, int amount) {
        int need = amount;
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length && need > 0; i++) {
            ItemStack s = contents[i];
            if (s == null || s.getType() != mat || s.hasItemMeta()) continue;
            int take = Math.min(need, s.getAmount());
            if (take >= s.getAmount()) {
                p.getInventory().setItem(i, null);
            } else {
                s.setAmount(s.getAmount() - take);
                p.getInventory().setItem(i, s);
            }
            need -= take;
        }
        return amount - need;
    }

    private String nice(Material m) {
        String[] parts = m.name().toLowerCase().split("_");
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return sb.toString();
    }
}
