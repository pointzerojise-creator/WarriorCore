package com.warrior.warriorcore;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class Util {

    private Util() {}

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    /** Options that start with the typed prefix (for tab completion). */
    public static List<String> match(Collection<String> options, String prefix) {
        List<String> out = new ArrayList<>();
        String low = prefix == null ? "" : prefix.toLowerCase();
        for (String o : options) {
            if (o.toLowerCase().startsWith(low)) out.add(o);
        }
        return out;
    }

    public static List<String> onlineNames() {
        List<String> names = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
        return names;
    }
}
