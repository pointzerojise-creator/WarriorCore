package com.warrior.warriorcore.worlds;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

/** Forces the per-world gamemode when players join, respawn or change world. */
public class WorldsListener implements Listener {

    private final WorldsModule module;

    public WorldsListener(WorldsModule module) {
        this.module = module;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        schedule(e.getPlayer());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        schedule(e.getPlayer());
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        schedule(e.getPlayer());
    }

    private void schedule(Player p) {
        Bukkit.getScheduler().runTaskLater(module.core(), () -> apply(p), 1L);
    }

    private void apply(Player p) {
        if (!p.isOnline()) return;
        GameMode gm = module.gamemodeOf(p.getWorld());
        if (gm == null) return;
        if (p.hasPermission("warriorcore.worlds.bypass")) return;
        if (p.getGameMode() != gm) p.setGameMode(gm);
    }
}
