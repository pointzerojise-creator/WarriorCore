package com.warrior.warriorcore.menu;

import com.warrior.warriorcore.Util;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** /menu open <id> [player]   /menu list   /menu <id> */
public class MenuCommand implements TabExecutor {

    private final MenuModule menus;

    public MenuCommand(MenuModule menus) {
        this.menus = menus;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("list")) {
            sender.sendMessage(menus.msg("list-header"));
            for (String id : menus.menuIds()) sender.sendMessage(menus.color("  &f" + id));
            return true;
        }

        int idIndex = args[0].equalsIgnoreCase("open") ? 1 : 0;
        if (args.length <= idIndex) {
            sender.sendMessage(menus.msg("unknown-menu"));
            return true;
        }
        String id = args[idIndex];
        if (menus.menu(id) == null) {
            sender.sendMessage(menus.msg("unknown-menu"));
            return true;
        }

        Player target;
        if (args.length > idIndex + 1) {
            if (!sender.hasPermission("warriorcore.menu.admin")) {
                sender.sendMessage(menus.msg("no-permission"));
                return true;
            }
            target = Bukkit.getPlayerExact(args[idIndex + 1]);
            if (target == null) {
                sender.sendMessage(menus.msg("player-not-found"));
                return true;
            }
        } else if (sender instanceof Player self) {
            target = self;
        } else {
            sender.sendMessage(menus.msg("players-only"));
            return true;
        }
        menus.open(target, id);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> options = new ArrayList<>(menus.menuIds());
            options.add("open");
            options.add("list");
            return Util.match(options, args[0]);
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("open")) return Util.match(menus.menuIds(), args[1]);
        if (args.length == 3 && args[0].equalsIgnoreCase("open") && sender.hasPermission("warriorcore.menu.admin")) {
            return Util.match(Util.onlineNames(), args[2]);
        }
        return List.of();
    }
}
