package com.warrior.warriorcore.lobby;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

public class LobbyListener implements Listener {

    private final LobbyModule lobby;

    public LobbyListener(LobbyModule lobby) {
        this.lobby = lobby;
    }

    // ----------------------------------------------------------- join / world

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(lobby.core(), () -> {
            if (!p.isOnline()) return;
            if (lobby.cfg().getBoolean("teleport-on-join", true)) {
                lobby.teleportToLobby(p);
            }
            lobby.refresh(p);
        }, 2L);
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(lobby.core(), () -> {
            if (p.isOnline()) lobby.refresh(p);
        }, 2L);
    }

    // -------------------------------------------------------------- join items

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action action = e.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        String key = lobby.keyOf(e.getItem());
        if (key == null) return;
        e.setCancelled(true);

        String cmd = lobby.cfg().getString("join-items." + key + ".command", "");
        if (cmd.startsWith("/")) cmd = cmd.substring(1);
        if (!cmd.isEmpty()) e.getPlayer().performCommand(cmd);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!lobby.isLobbyWorld(p.getWorld()) || p.hasPermission(LobbyModule.BYPASS)) return;

        boolean touchesLobbyItem = lobby.keyOf(e.getCurrentItem()) != null || lobby.keyOf(e.getCursor()) != null;
        if (!touchesLobbyItem && e.getHotbarButton() >= 0) {
            ItemStack hotbar = p.getInventory().getItem(e.getHotbarButton());
            touchesLobbyItem = lobby.keyOf(hotbar) != null;
        }
        if (touchesLobbyItem) e.setCancelled(true);
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        if (lobby.keyOf(e.getMainHandItem()) != null || lobby.keyOf(e.getOffHandItem()) != null) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        Player p = e.getPlayer();
        if (lobby.keyOf(e.getItemDrop().getItemStack()) != null) {
            e.setCancelled(true);
            return;
        }
        if (lobby.protects(p.getWorld(), "item-drop") && !p.hasPermission(LobbyModule.BYPASS)) {
            e.setCancelled(true);
        }
    }

    // -------------------------------------------------------------- protection

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (lobby.protects(e.getBlock().getWorld(), "block-break") && !e.getPlayer().hasPermission(LobbyModule.BYPASS)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (lobby.protects(e.getBlock().getWorld(), "block-place") && !e.getPlayer().hasPermission(LobbyModule.BYPASS)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (lobby.protects(p.getWorld(), "damage")) e.setCancelled(true);
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        if (lobby.protects(p.getWorld(), "hunger")) e.setCancelled(true);
    }

    @EventHandler
    public void onMobSpawn(CreatureSpawnEvent e) {
        if (e.getLocation().getWorld() == null) return;
        if (lobby.protects(e.getLocation().getWorld(), "mob-spawn")
                && e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM) {
            e.setCancelled(true);
        }
    }

    // --------------------------------------------------------------- void rescue

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        Location to = e.getTo();
        if (to == null) return;
        if (to.getY() >= lobby.cfg().getDouble("void-teleport-y", -10.0)) return;
        if (!lobby.isLobbyWorld(to.getWorld())) return;

        Player p = e.getPlayer();
        p.setFallDistance(0f);
        p.setVelocity(new Vector(0, 0, 0));
        lobby.teleportToLobby(p);
    }
}
