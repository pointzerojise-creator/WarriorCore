package com.warrior.warriorcore;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;

import java.util.List;

/** /warriorcore (alias /wcore): reload and module list. */
public class CoreCommand implements TabExecutor {

    private final WarriorCore core;

    public CoreCommand(WarriorCore core) {
        this.core = core;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("warriorcore.admin")) {
            sender.sendMessage(Util.color("&cYou don't have permission."));
            return true;
        }
        String sub = args.length == 0 ? "modules" : args[0].toLowerCase();
        switch (sub) {
            case "reload":
                core.reloadAll();
                sender.sendMessage(Util.color("&8[&6WarriorCore&8] &aReloaded config and modules."));
                return true;
            case "modules":
                sender.sendMessage(Util.color("&8[&6WarriorCore&8] &7Modules (turn on/off in config.yml, then restart):"));
                for (CoreModule m : core.modules().all()) {
                    boolean on = core.modules().isEnabled(m);
                    sender.sendMessage(Util.color("  " + (on ? "&a\u2714 " : "&c\u2718 ") + "&f" + m.id()));
                }
                return true;
            default:
                sender.sendMessage(Util.color("&cUsage: /wcore <reload|modules>"));
                return true;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) return Util.match(List.of("reload", "modules"), args[0]);
        return List.of();
    }
}
