package com.warrior.warriorcore.lobby;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import com.warrior.warriorcore.worlds.WorldsModule;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Lobby: /lobby, join items, protection, void rescue. */
public class LobbyModule extends CoreModule {

    public static final String BYPASS = "warriorcore.lobby.bypass";

    private File dataFile;
    private YamlConfiguration data;
    private NamespacedKey itemKey;

    public LobbyModule(WarriorCore core) {
        super(core, "lobby");
    }

    @Override
    public void enable() {
        itemKey = new NamespacedKey(core, "lobby_item");
        dataFile = new File(core.getDataFolder(), "lobby-data.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);

        LobbyCommand handler = new LobbyCommand(this);
        command("lobby", handler);
        command("setlobby", handler);
        listen(new LobbyListener(this));

        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    @Override
    public void reload() {
        loadConfig();
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    // ---------------------------------------------------------------- location

    public String lobbyWorldName() {
        String saved = data.getString("lobby.world");
        return saved != null ? saved : cfg().getString("world", "lobby");
    }

    public boolean isLobbyWorld(World w) {
        return w != null && w.getName().equalsIgnoreCase(lobbyWorldName());
    }

    /** Saved lobby spot, otherwise the spawn of the configured lobby world, otherwise null. */
    public Location lobbyLocation() {
        String name = data.getString("lobby.world");
        if (name != null) {
            World w = Bukkit.getWorld(name);
            if (w != null) {
                return new Location(w, data.getDouble("lobby.x"), data.getDouble("lobby.y"), data.getDouble("lobby.z"),
                        (float) data.getDouble("lobby.yaw"), (float) data.getDouble("lobby.pitch"));
            }
        }
        World w = Bukkit.getWorld(cfg().getString("world", "lobby"));
        if (w == null) return null;
        WorldsModule worlds = core.modules().get(WorldsModule.class);
        return worlds != null ? worlds.spawnOf(w) : w.getSpawnLocation().add(0.5, 0, 0.5);
    }

    public boolean teleportToLobby(Player p) {
        Location loc = lobbyLocation();
        if (loc == null) return false;
        p.teleport(loc);
        return true;
    }

    public void setLobby(Location loc) {
        World w = loc.getWorld();
        if (w == null) return;
        data.set("lobby.world", w.getName());
        data.set("lobby.x", loc.getX());
        data.set("lobby.y", loc.getY());
        data.set("lobby.z", loc.getZ());
        data.set("lobby.yaw", (double) loc.getYaw());
        data.set("lobby.pitch", (double) loc.getPitch());
        try {
            data.save(dataFile);
        } catch (IOException ex) {
            getLogger().warning("[lobby] could not save lobby-data.yml: " + ex.getMessage());
        }
    }

    // -------------------------------------------------------------- protection

    public boolean protects(World w, String flag) {
        return cfg().getBoolean("protection.enabled", true)
                && isLobbyWorld(w)
                && cfg().getBoolean("protection." + flag, true);
    }

    // -------------------------------------------------------------- join items

    /** Id from config (join-items.<id>) if this is one of our lobby items, otherwise null. */
    public String keyOf(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return null;
        return meta.getPersistentDataContainer().get(itemKey, PersistentDataType.STRING);
    }

    public void giveItems(Player p) {
        ConfigurationSection items = cfg().getConfigurationSection("join-items");
        if (items == null) return;
        for (String key : items.getKeys(false)) {
            ConfigurationSection s = items.getConfigurationSection(key);
            if (s == null) continue;
            Material mat = Material.matchMaterial(s.getString("material", "COMPASS"));
            if (mat == null || !mat.isItem() || mat.isAir()) mat = Material.COMPASS;
            ItemStack stack = new ItemStack(mat);
            ItemMeta meta = stack.getItemMeta();
            if (meta == null) continue;
            meta.setDisplayName(color(s.getString("name", key)));
            List<String> lore = new ArrayList<>();
            for (String line : s.getStringList("lore")) lore.add(color(line));
            if (!lore.isEmpty()) meta.setLore(lore);
            meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, key);
            stack.setItemMeta(meta);
            int slot = Math.max(0, Math.min(8, s.getInt("slot", 0)));
            p.getInventory().setItem(slot, stack);
        }
    }

    public void removeItems(Player p) {
        ItemStack[] contents = p.getInventory().getStorageContents();
        for (int i = 0; i < contents.length; i++) {
            if (keyOf(contents[i]) != null) p.getInventory().setItem(i, null);
        }
    }

    /** Gives lobby items in the lobby world, removes them everywhere else. */
    public void refresh(Player p) {
        if (isLobbyWorld(p.getWorld())) {
            giveItems(p);
        } else {
            removeItems(p);
        }
    }
}
