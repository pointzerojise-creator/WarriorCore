package com.warrior.warriorcore.lifesteal.commands;

import com.warrior.warriorcore.Util;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class HeartsCommand implements TabExecutor {

    private final LifestealModule plugin;

    public HeartsCommand(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(plugin.msg("players-only"));
                return true;
            }
            sender.sendMessage(plugin.msg("hearts-self",
                    "hearts", String.valueOf(plugin.hearts().getHearts(p.getUniqueId()))));
            return true;
        }

        UUID id = plugin.findPlayer(args[0]);
        if (id == null) {
            sender.sendMessage(plugin.msg("player-not-found"));
            return true;
        }
        sender.sendMessage(plugin.msg("hearts-other",
                "player", plugin.hearts().nameOf(id),
                "hearts", String.valueOf(plugin.hearts().getHearts(id))));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            return Util.match(names, args[0]);
        }
        return List.of();
    }
}
