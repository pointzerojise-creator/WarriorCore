package com.warrior.warriorcore.lifesteal;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Stores hearts / elimination state per player UUID and persists them to data.yml. */
public class HeartManager {

    private final LifestealModule plugin;
    private final File file;
    private final Object fileLock = new Object();

    private final Map<UUID, Integer> hearts = new ConcurrentHashMap<>();
    private final Map<UUID, String> names = new ConcurrentHashMap<>();
    private final Set<UUID> eliminated = ConcurrentHashMap.newKeySet();

    private List<UUID> topCache = new ArrayList<>();
    private long topCacheTime = 0L;

    public HeartManager(LifestealModule plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.core().getDataFolder(), "lifesteal-data.yml");
    }

    // ------------------------------------------------------------- settings

    public int maxHearts() {
        return Math.max(1, plugin.getConfig().getInt("hearts.max", 20));
    }

    public int startHearts() {
        int start = plugin.getConfig().getInt("hearts.start", 10);
        return Math.max(1, Math.min(start, maxHearts()));
    }

    // ----------------------------------------------------------------- data

    public int getHearts(UUID id) {
        return hearts.getOrDefault(id, startHearts());
    }

    /** Sets hearts (clamped to 0..max). 0 marks the player eliminated, anything above clears it. */
    public void setHearts(UUID id, int amount) {
        int value = Math.max(0, Math.min(amount, maxHearts()));
        hearts.put(id, value);
        if (value == 0) {
            eliminated.add(id);
        } else {
            eliminated.remove(id);
        }
    }

    public boolean isEliminated(UUID id) {
        return eliminated.contains(id);
    }

    public void rememberPlayer(UUID id, String name) {
        names.put(id, name);
        hearts.putIfAbsent(id, startHearts());
    }

    public String nameOf(UUID id) {
        String n = names.get(id);
        return n == null ? "Unknown" : n;
    }

    public UUID findByName(String name) {
        for (Map.Entry<UUID, String> e : names.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    public List<String> eliminatedNames() {
        List<String> out = new ArrayList<>();
        for (UUID id : eliminated) out.add(nameOf(id));
        return out;
    }

    public List<String> knownNames() {
        return new ArrayList<>(names.values());
    }

    /** Players sorted by hearts (highest first). Cached for 5 seconds. */
    public synchronized List<UUID> top() {
        long now = System.currentTimeMillis();
        if (now - topCacheTime > 5000L) {
            List<UUID> ids = new ArrayList<>(hearts.keySet());
            ids.sort((a, b) -> {
                int c = Integer.compare(getHearts(b), getHearts(a));
                return c != 0 ? c : nameOf(a).compareToIgnoreCase(nameOf(b));
            });
            topCache = ids;
            topCacheTime = now;
        }
        return topCache;
    }

    // ---------------------------------------------------------- elimination

    /** Sets a player to 0 hearts and runs the elimination messages / commands (next tick). */
    public void eliminate(UUID id) {
        setHearts(id, 0);
        final String name = nameOf(id);
        Bukkit.getScheduler().runTask(plugin.core(), () -> {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                p.sendMessage(plugin.msg("eliminated-self"));
                plugin.applyState(p);
            }
            if (plugin.getConfig().getBoolean("elimination.broadcast", true)) {
                Bukkit.broadcastMessage(plugin.msg("eliminated-broadcast", "player", name));
            }
            for (String cmd : plugin.getConfig().getStringList("elimination.commands")) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", name));
            }
        });
    }

    /** Brings a player back with the given hearts and runs the revive commands. */
    public void revive(UUID id, int amount) {
        int value = Math.max(1, Math.min(amount, maxHearts()));
        setHearts(id, value);
        String name = nameOf(id);

        for (String cmd : plugin.getConfig().getStringList("elimination.revive-commands")) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", name));
        }

        Player p = Bukkit.getPlayer(id);
        if (p != null) {
            if (plugin.isActiveIn(p.getWorld()) && p.getGameMode() == GameMode.SPECTATOR) {
                p.setGameMode(GameMode.SURVIVAL);
            }
            plugin.applyState(p);
            p.sendMessage(plugin.msg("revived-target", "hearts", String.valueOf(value)));
        }
        if (plugin.getConfig().getBoolean("elimination.broadcast", true)) {
            Bukkit.broadcastMessage(plugin.msg("revived-broadcast", "player", name));
        }
    }

    // ----------------------------------------------------------- persistence

    public void load() {
        plugin.core().getDataFolder().mkdirs();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection players = y.getConfigurationSection("players");
        if (players == null) return;
        for (String key : players.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            hearts.put(id, players.getInt(key + ".hearts", startHearts()));
            String name = players.getString(key + ".name");
            if (name != null) names.put(id, name);
            if (players.getBoolean(key + ".eliminated", false)) eliminated.add(id);
        }
        plugin.getLogger().info("Loaded " + hearts.size() + " player(s) from data.yml");
    }

    public void saveSync() {
        write(new HashMap<>(hearts), new HashMap<>(names), new HashSet<>(eliminated));
    }

    /** Copies the data on the calling (main) thread, then writes the file async. */
    public void saveAsync() {
        final Map<UUID, Integer> h = new HashMap<>(hearts);
        final Map<UUID, String> n = new HashMap<>(names);
        final Set<UUID> e = new HashSet<>(eliminated);
        Bukkit.getScheduler().runTaskAsynchronously(plugin.core(), () -> write(h, n, e));
    }

    private void write(Map<UUID, Integer> h, Map<UUID, String> n, Set<UUID> el) {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Integer> entry : h.entrySet()) {
            String base = "players." + entry.getKey();
            y.set(base + ".hearts", entry.getValue());
            String name = n.get(entry.getKey());
            if (name != null) y.set(base + ".name", name);
            if (el.contains(entry.getKey())) y.set(base + ".eliminated", true);
        }
        synchronized (fileLock) {
            File tmp = new File(plugin.core().getDataFolder(), "lifesteal-data.yml.tmp");
            try {
                y.save(tmp);
                Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException ex) {
                plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage());
            }
        }
    }
}
