package com.warrior.warriorcore.lifesteal.commands;

import com.warrior.warriorcore.lifesteal.HeartManager;
import com.warrior.warriorcore.lifesteal.ItemManager;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public class WithdrawheartCommand implements TabExecutor {

    private final LifestealModule plugin;

    public WithdrawheartCommand(LifestealModule plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(plugin.msg("players-only"));
            return true;
        }
        if (!plugin.isActiveIn(p.getWorld())) {
            p.sendMessage(plugin.msg("not-in-world"));
            return true;
        }

        int items = 1;
        if (args.length > 0) {
            try {
                items = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex) {
                p.sendMessage(plugin.msg("invalid-number"));
                return true;
            }
        }
        if (items < 1 || items > 64) {
            p.sendMessage(plugin.msg("invalid-number"));
            return true;
        }

        HeartManager hm = plugin.hearts();
        UUID id = p.getUniqueId();
        int perItem = Math.max(1, plugin.getConfig().getInt("items.heart.hearts-given", 1));
        int cost = items * perItem;
        int min = Math.max(1, plugin.getConfig().getInt("hearts.min-to-withdraw", 1));
        int current = hm.getHearts(id);

        if (current - cost < min) {
            p.sendMessage(plugin.msg("withdraw-too-low", "min", String.valueOf(min)));
            return true;
        }

        ItemStack stack = plugin.items().build(ItemManager.HEART, items);
        if (stack == null) {
            p.sendMessage(plugin.msg("unknown-item"));
            return true;
        }

        hm.setHearts(id, current - cost);
        Map<Integer, ItemStack> left = p.getInventory().addItem(stack);
        for (ItemStack extra : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), extra);
        }
        plugin.applyState(p);
        p.sendMessage(plugin.msg("heart-withdrawn",
                "amount", String.valueOf(cost), "hearts", String.valueOf(current - cost)));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
