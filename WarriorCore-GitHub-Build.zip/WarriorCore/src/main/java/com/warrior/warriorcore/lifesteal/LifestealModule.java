package com.warrior.warriorcore.lifesteal;

import com.warrior.warriorcore.CoreModule;
import com.warrior.warriorcore.WarriorCore;
import com.warrior.warriorcore.lifesteal.commands.HeartsCommand;
import com.warrior.warriorcore.lifesteal.commands.ReviveCommand;
import com.warrior.warriorcore.lifesteal.commands.WarriorlifestealCommand;
import com.warrior.warriorcore.lifesteal.commands.WithdrawheartCommand;
import com.warrior.warriorcore.lifesteal.hooks.LifestealExpansion;
import com.warrior.warriorcore.lifesteal.listeners.MainListener;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.List;
import java.util.UUID;

/** Lifesteal: hearts, heart item, revive, elimination. Config: modules/lifesteal.yml */
public final class LifestealModule extends CoreModule {

    private HeartManager heartManager;
    private ItemManager itemManager;
    private Attribute maxHealthAttribute;
    private BukkitTask autosave;

    public LifestealModule(WarriorCore core) {
        super(core, "lifesteal");
    }

    @Override
    public void enable() {
        maxHealthAttribute = resolveMaxHealthAttribute();
        if (maxHealthAttribute == null) {
            getLogger().warning("[lifesteal] Could not find the max health attribute - hearts will not change max health!");
        }

        heartManager = new HeartManager(this);
        heartManager.load();
        itemManager = new ItemManager(this);
        itemManager.registerRecipes();

        command("hearts", new HeartsCommand(this));
        command("withdrawheart", new WithdrawheartCommand(this));
        command("revive", new ReviveCommand(this));
        command("warriorlifesteal", new WarriorlifestealCommand(this));

        listen(new MainListener(this));

        if (core.getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            try {
                new LifestealExpansion(this).register();
                getLogger().info("[lifesteal] PlaceholderAPI found - %warriorlifesteal_...% placeholders registered.");
            } catch (Exception | LinkageError ex) {
                getLogger().warning("[lifesteal] Could not register PlaceholderAPI expansion: " + ex);
            }
        }

        autosave = Bukkit.getScheduler().runTaskTimer(core, () -> heartManager.saveAsync(), 20L * 120, 20L * 120);

        for (Player p : Bukkit.getOnlinePlayers()) {
            heartManager.rememberPlayer(p.getUniqueId(), p.getName());
            applyState(p);
        }
    }

    @Override
    public void disable() {
        if (autosave != null) autosave.cancel();
        if (heartManager != null) heartManager.saveSync();
        if (itemManager != null) itemManager.unregisterRecipes();
    }

    @Override
    public void reload() {
        loadConfig();
        itemManager.registerRecipes();
        for (Player p : Bukkit.getOnlinePlayers()) {
            applyState(p);
        }
    }

    public HeartManager hearts() { return heartManager; }

    public ItemManager items() { return itemManager; }

    /** True if lifesteal is active in this world. Empty enabled-worlds list = everywhere. */
    public boolean isActiveIn(World world) {
        List<String> worlds = getConfig().getStringList("enabled-worlds");
        if (worlds.isEmpty()) return true;
        if (world == null) return false;
        for (String w : worlds) {
            if (w.equalsIgnoreCase(world.getName())) return true;
        }
        return false;
    }

    /** Online player by exact name, otherwise a known (previously joined) player. */
    public UUID findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        return heartManager.findByName(name);
    }

    /** Applies max health (hearts x 2) and elimination state for this player's current world. */
    public void applyState(Player p) {
        if (p == null || !p.isOnline() || p.isDead()) return;
        boolean active = isActiveIn(p.getWorld());
        double hp;
        if (active) {
            int h = heartManager.getHearts(p.getUniqueId());
            hp = Math.max(2.0, h * 2.0);
        } else if (getConfig().getBoolean("reset-health-outside-worlds", true)) {
            hp = 20.0;
        } else {
            return;
        }

        if (maxHealthAttribute != null) {
            AttributeInstance inst = p.getAttribute(maxHealthAttribute);
            if (inst != null) {
                if (inst.getBaseValue() != hp) inst.setBaseValue(hp);
                if (p.getHealth() > hp) p.setHealth(hp);
            }
        }

        String mode = getConfig().getString("elimination.mode", "SPECTATOR");
        if (active && "SPECTATOR".equalsIgnoreCase(mode)
                && heartManager.isEliminated(p.getUniqueId())
                && p.getGameMode() != GameMode.SPECTATOR) {
            p.setGameMode(GameMode.SPECTATOR);
        }
    }

    /** The max-health attribute was renamed in 1.21.3, so look it up by name instead of by constant. */
    private Attribute resolveMaxHealthAttribute() {
        for (String fieldName : new String[]{"MAX_HEALTH", "GENERIC_MAX_HEALTH"}) {
            try {
                Object value = Attribute.class.getField(fieldName).get(null);
                if (value instanceof Attribute attr) return attr;
            } catch (ReflectiveOperationException ignored) {
                // try the next name
            }
        }
        return null;
    }
}
