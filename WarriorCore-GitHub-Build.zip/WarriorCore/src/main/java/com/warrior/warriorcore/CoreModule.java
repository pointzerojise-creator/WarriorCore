package com.warrior.warriorcore;

import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;

import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/** Base class for every WarriorCore module. Each module has its own file: plugins/WarriorCore/modules/<id>.yml */
public abstract class CoreModule {

    protected final WarriorCore core;
    private final String id;
    private YamlConfiguration cfg = new YamlConfiguration();
    private final List<Listener> listeners = new ArrayList<>();

    protected CoreModule(WarriorCore core, String id) {
        this.core = core;
        this.id = id;
    }

    public String id() { return id; }

    public WarriorCore core() { return core; }

    public Logger getLogger() { return core.getLogger(); }

    /** (Re)loads modules/<id>.yml, copying the default file out of the jar the first time. */
    public void loadConfig() {
        File file = new File(core.getDataFolder(), "modules/" + id + ".yml");
        if (!file.exists()) {
            core.saveResource("modules/" + id + ".yml", false);
        }
        YamlConfiguration loaded = YamlConfiguration.loadConfiguration(file);
        InputStream in = core.getResource("modules/" + id + ".yml");
        if (in != null) {
            loaded.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
        }
        this.cfg = loaded;
    }

    public FileConfiguration getConfig() { return cfg; }

    public FileConfiguration cfg() { return cfg; }

    /** Called once when the module is switched on. */
    public abstract void enable();

    /** Called when the server stops. */
    public void disable() {}

    /** Called by /wcore reload (the module config was already re-read by loadConfig()). */
    public void reload() {
        loadConfig();
    }

    protected void listen(Listener listener) {
        core.getServer().getPluginManager().registerEvents(listener, core);
        listeners.add(listener);
    }

    protected void command(String name, TabExecutor executor) {
        PluginCommand cmd = core.getCommand(name);
        if (cmd == null) {
            getLogger().warning("[" + id + "] command missing from plugin.yml: " + name);
            return;
        }
        cmd.setExecutor(executor);
        cmd.setTabCompleter(executor);
    }

    public void unregisterListeners() {
        for (Listener l : listeners) HandlerList.unregisterAll(l);
        listeners.clear();
    }

    // ---------------------------------------------------------------- messages

    public String color(String text) {
        return Util.color(text);
    }

    /** Replace %key% placeholders. pairs = key1, value1, key2, value2 ... */
    public String fill(String text, String... pairs) {
        String out = text;
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            out = out.replace("%" + pairs[i] + "%", pairs[i + 1]);
        }
        return out;
    }

    /** Prefixed message from this module's config: messages.<key>. */
    public String msg(String key, String... pairs) {
        String text = cfg.getString("messages." + key, key);
        return color(cfg.getString("prefix", "") + fill(text, pairs));
    }
}
