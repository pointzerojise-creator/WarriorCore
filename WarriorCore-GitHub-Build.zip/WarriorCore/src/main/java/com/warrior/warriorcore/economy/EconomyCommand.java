package com.warrior.warriorcore.economy;

import com.warrior.warriorcore.Util;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

/** One executor for /balance, /pay, /baltop and /eco (picked by command name). */
public class EconomyCommand implements TabExecutor {

    private final EconomyModule eco;

    public EconomyCommand(EconomyModule eco) {
        this.eco = eco;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase()) {
            case "balance": return balance(sender, args);
            case "pay": return pay(sender, args);
            case "baltop": return baltop(sender, args);
            case "eco": return admin(sender, args);
            default: return false;
        }
    }

    private boolean balance(CommandSender sender, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(eco.msg("players-only"));
                return true;
            }
            sender.sendMessage(eco.msg("balance-self", "balance", eco.format(eco.getBalance(p.getUniqueId()))));
            return true;
        }
        UUID id = eco.findPlayer(args[0]);
        if (id == null) {
            sender.sendMessage(eco.msg("player-not-found"));
            return true;
        }
        sender.sendMessage(eco.msg("balance-other", "player", eco.nameOf(id), "balance", eco.format(eco.getBalance(id))));
        return true;
    }

    private boolean pay(CommandSender sender, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(eco.msg("players-only"));
            return true;
        }
        if (args.length < 2) {
            p.sendMessage(eco.msg("pay-usage"));
            return true;
        }
        UUID target = eco.findPlayer(args[0]);
        if (target == null) {
            p.sendMessage(eco.msg("player-not-found"));
            return true;
        }
        if (target.equals(p.getUniqueId())) {
            p.sendMessage(eco.msg("pay-self"));
            return true;
        }
        Long cents = eco.parse(args[1], false);
        if (cents == null) {
            p.sendMessage(eco.msg("invalid-amount"));
            return true;
        }
        if (cents < eco.minPayCents()) {
            p.sendMessage(eco.msg("pay-min", "min", eco.format(eco.minPayCents())));
            return true;
        }
        if (!eco.withdraw(p.getUniqueId(), cents)) {
            p.sendMessage(eco.msg("not-enough"));
            return true;
        }
        eco.deposit(target, cents);
        p.sendMessage(eco.msg("pay-sent", "amount", eco.format(cents), "player", eco.nameOf(target)));
        Player online = Bukkit.getPlayer(target);
        if (online != null) {
            online.sendMessage(eco.msg("pay-received", "amount", eco.format(cents), "player", p.getName()));
        }
        return true;
    }

    private boolean baltop(CommandSender sender, String[] args) {
        List<UUID> top = eco.top();
        if (top.isEmpty()) {
            sender.sendMessage(eco.msg("baltop-empty"));
            return true;
        }
        int perPage = 10;
        int pages = (top.size() + perPage - 1) / perPage;
        int page = 1;
        if (args.length > 0) {
            try {
                page = Integer.parseInt(args[0]);
            } catch (NumberFormatException ex) {
                page = 1;
            }
        }
        page = Math.max(1, Math.min(page, pages));

        sender.sendMessage(eco.msg("baltop-header", "page", String.valueOf(page), "pages", String.valueOf(pages)));
        int start = (page - 1) * perPage;
        for (int i = start; i < Math.min(top.size(), start + perPage); i++) {
            UUID id = top.get(i);
            String line = eco.cfg().getString("messages.baltop-line", "%pos% %player% %balance%");
            sender.sendMessage(eco.color(eco.fill(line,
                    "pos", String.valueOf(i + 1),
                    "player", eco.nameOf(id),
                    "balance", eco.format(eco.getBalance(id)))));
        }
        return true;
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("warriorcore.economy.admin")) {
            sender.sendMessage(eco.msg("no-permission"));
            return true;
        }
        if (args.length < 2) {
            sender.sendMessage(eco.msg("eco-usage"));
            return true;
        }
        String sub = args[0].toLowerCase();
        UUID id = eco.findPlayer(args[1]);
        if (id == null) {
            sender.sendMessage(eco.msg("player-not-found"));
            return true;
        }

        if (sub.equals("reset")) {
            eco.set(id, eco.startCents());
        } else if (sub.equals("give") || sub.equals("take") || sub.equals("set")) {
            if (args.length < 3) {
                sender.sendMessage(eco.msg("eco-usage"));
                return true;
            }
            Long cents = eco.parse(args[2], sub.equals("set"));
            if (cents == null) {
                sender.sendMessage(eco.msg("invalid-amount"));
                return true;
            }
            if (sub.equals("give")) {
                eco.deposit(id, cents);
            } else if (sub.equals("set")) {
                eco.set(id, cents);
            } else if (!eco.withdraw(id, cents)) {
                sender.sendMessage(eco.msg("eco-take-failed", "player", eco.nameOf(id)));
                return true;
            }
        } else {
            sender.sendMessage(eco.msg("eco-usage"));
            return true;
        }
        sender.sendMessage(eco.msg("eco-done", "player", eco.nameOf(id), "balance", eco.format(eco.getBalance(id))));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        String name = command.getName().toLowerCase();
        if (name.equals("balance") || name.equals("pay")) {
            if (args.length == 1) return Util.match(Util.onlineNames(), args[0]);
            return List.of();
        }
        if (name.equals("eco") && sender.hasPermission("warriorcore.economy.admin")) {
            if (args.length == 1) return Util.match(List.of("give", "take", "set", "reset"), args[0]);
            if (args.length == 2) return Util.match(eco.knownNames(), args[1]);
        }
        return List.of();
    }
}
