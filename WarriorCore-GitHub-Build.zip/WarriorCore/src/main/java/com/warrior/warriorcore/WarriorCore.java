package com.warrior.warriorcore;

import com.warrior.warriorcore.economy.EconomyModule;
import com.warrior.warriorcore.lifesteal.LifestealModule;
import com.warrior.warriorcore.lobby.LobbyModule;
import com.warrior.warriorcore.menu.MenuModule;
import com.warrior.warriorcore.shop.ShopModule;
import com.warrior.warriorcore.worlds.WorldsModule;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public final class WarriorCore extends JavaPlugin {

    private ModuleManager modules;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        // Every command starts as "turned off"; a module takes its commands over when it starts.
        for (String name : getDescription().getCommands().keySet()) {
            PluginCommand c = getCommand(name);
            if (c == null) continue;
            c.setExecutor((sender, cmd, label, args) -> {
                sender.sendMessage(Util.color("&cThat feature is turned off in WarriorCore's config.yml."));
                return true;
            });
            c.setTabCompleter((sender, cmd, label, args) -> List.of());
        }

        modules = new ModuleManager(this);
        // Order matters: worlds first, economy before shop.
        modules.add(new WorldsModule(this));
        modules.add(new EconomyModule(this));
        modules.add(new ShopModule(this));
        modules.add(new LifestealModule(this));
        modules.add(new LobbyModule(this));
        modules.add(new MenuModule(this));
        modules.enableAll();

        PluginCommand wcore = getCommand("warriorcore");
        if (wcore != null) {
            CoreCommand handler = new CoreCommand(this);
            wcore.setExecutor(handler);
            wcore.setTabCompleter(handler);
        }
        getLogger().info("WarriorCore enabled.");
    }

    @Override
    public void onDisable() {
        if (modules != null) modules.disableAll();
        getLogger().info("WarriorCore disabled.");
    }

    public ModuleManager modules() {
        return modules;
    }

    public void reloadAll() {
        reloadConfig();
        modules.reloadAll();
    }
}
